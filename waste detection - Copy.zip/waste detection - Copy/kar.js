let map, tempMarker, uploadedImage;
    let markers = [];

    function initializeMap() {
      map = L.map("map", { zoomControl: false }).setView([12.9716, 77.5946], 13);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      loadKarnatakaBorder();
      map.on("zoomend", updateMarkerAppearance);
      document.addEventListener("keydown", handleEscapeKey);
    }

    function loadKarnatakaBorder() {
      const geojsonUrl = "https://raw.githubusercontent.com/datameet/maps/master/States/Karnataka.geojson";
      axios.get(geojsonUrl).then(response => {
        L.geoJSON(response.data, { style: { color: "#00008B", weight: 4, fillOpacity: 0 } }).addTo(map);
      }).catch(error => console.error("Error loading Karnataka border:", error));
    }

    function openFileDialog() {
      const fileInput = document.createElement("input");
      fileInput.type = "file"; fileInput.accept = "image/*";
      fileInput.onchange = function (event) {
        const file = event.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function (e) {
            uploadedImage = e.target.result;
            alert("Now click on the map to place the image.");
            enableMapClick();
          };
          reader.readAsDataURL(file);
        }
      };
      fileInput.click();
    }

    function enableMapClick() {
    map.once("click", function (e) {
        if (uploadedImage) {
            if (tempMarker) map.removeLayer(tempMarker);
            tempMarker = L.marker(e.latlng).addTo(map).bindPopup("Click 'Confirm' to finalize.").openPopup();
            document.querySelector(".confirm-btn").style.display = "block";
        }
    });
}

function confirmPlacement() {
    if (tempMarker && uploadedImage) {
        let markerLatLng = tempMarker.getLatLng();
        map.removeLayer(tempMarker);

        let marker = {
            latlng: markerLatLng,
            imageUrl: uploadedImage,
            redDot: L.marker(markerLatLng, { icon: getRedDotIcon(1) }).addTo(map),
            imageMarker: L.marker(markerLatLng, { icon: getCustomImageIcon(uploadedImage, 50) }).addTo(map),
        };

        // Make the image marker clickable (redirects to profile.html)
        marker.imageMarker.on('click', function () {
            window.location.href = "profile1.html"; 
            // Change to your target page
        });

        marker.imageMarker.setOpacity(0);
        markers.push(marker);
        document.querySelector(".confirm-btn").style.display = "none";
        updateMarkerAppearance();
    }
}

function handleEscapeKey(event) {
    if (event.key === "Escape") {
        if (tempMarker) {
            map.removeLayer(tempMarker);
            tempMarker = null;
        }
        document.querySelector(".confirm-btn").style.display = "none";
    }
}

function getRedDotIcon(opacity) {
    return L.divIcon({
        className: "custom-marker",
        html: `<div style="width: 12px; height: 12px; border-radius: 50%;
              background-color: rgba(255, 0, 0, ${opacity}); box-shadow: 0 0 5px rgba(255, 0, 0, ${opacity});"></div>`,
        iconSize: [12, 12], iconAnchor: [6, 6]
    });
}

function getCustomImageIcon(imageUrl, size) {
    return L.divIcon({
        className: "custom-marker",
        html: `<div style="width: ${size}px; height: ${size}px; border-radius: 50%;
              background: url('${imageUrl}') center/cover no-repeat;
              box-shadow: 0 0 10px 3px rgba(255, 0, 0, 0.7);
              border: 2px solid white;"></div>`,
        iconSize: [size, size], iconAnchor: [size / 2, size / 2]
    });
}

function updateMarkerAppearance() {
    let zoom = map.getZoom();
    markers.forEach(marker => {
        let size = Math.max(20, 60 - (18 - zoom) * 4);
        let opacity = Math.max(0, (zoom - 9) / 5);

        if (zoom >= 15) {
            marker.imageMarker.setIcon(getCustomImageIcon(marker.imageUrl, size));
            marker.imageMarker.setOpacity(1);
            marker.redDot.setOpacity(0);
        } else if (zoom >= 10) {
            marker.redDot.setOpacity(opacity);
            marker.imageMarker.setOpacity(0);
        } else {
            marker.redDot.setOpacity(0);
            marker.imageMarker.setOpacity(0);
        }
    });
}

// Initialize the map
initializeMap();
